<html>
	<head>
		<? require_once('head.php'); ?>
	</head>
</html>