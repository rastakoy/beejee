<?php
class Items extends Controller{
	
	/**
	
	
	public function __construct($url, $params){
		echo '<pre>'; print_r($url); echo '</pre>';
		echo '<pre>'; print_r($params); echo '</pre>';
		$this->test('qwer');
		$this->db->query('SELECT * FROM `items` ');
	}*/
	
	function itemsTest(){
		//echo "itemsTest<br/>\n";
		//$this->test('qwer');
	}
	
}